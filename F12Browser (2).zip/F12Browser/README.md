# F12 瀏覽器（Android）

手機上也能「按 F12」的瀏覽器：WebView + 內建 Eruda 開發者工具（離線可用）。

## 功能
- 網址列（可直接輸入關鍵字搜尋）、上一頁/下一頁、重新整理
- **F12 按鈕**：開/關開發者工具 — Console、Elements（元素）、Network（網路）、Resources（Cookie/LocalStorage）、Sources、Info
- ⋮ 選單：
  - 檢視原始碼（目前 DOM，含 JS 產生的內容）
  - 檢視原始碼（伺服器原始 HTML，等同電腦的 view-source:）— 可搜尋、複製
  - 每頁自動載入 F12
  - 電腦版網站（切換 User-Agent）
  - 清除快取與 Cookie
- 已開啟 WebView 遠端偵錯：手機接 USB，電腦 Chrome 開 `chrome://inspect` 就能用完整版 DevTools

## 編譯 APK

### 方法 A：GitHub 自動編譯（不用裝任何軟體，手機也能操作）
1. 在 GitHub 建一個新的 repository，把這個資料夾全部上傳
2. 上傳後會自動執行 Actions → 「Build APK」
3. 跑完（約 3–5 分鐘）點進該次執行，下方 Artifacts 下載 `F12Browser-apk`，解壓得到 `app-debug.apk`
4. 手機安裝（需允許「安裝不明來源的應用程式」）

### 方法 B：Android Studio
用 Android Studio 開啟此資料夾 → 等 Gradle 同步 → Build ▸ Build APK(s)。

## 注意
- 部分網站（Google 登入等）會擋 WebView 登入，這是網站的限制。
- Eruda 版本：3.4.3（MIT 授權），位於 app/src/main/assets/eruda.js
