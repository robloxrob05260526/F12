package tw.hilo.f12browser;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.*;
import android.widget.*;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final String HOME = "https://www.google.com";
    private static final String DESKTOP_UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36";

    private WebView web;
    private EditText urlBar;
    private ProgressBar progress;
    private SharedPreferences prefs;
    private String erudaJs;
    private String mobileUa;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("f12", MODE_PRIVATE);
        web = findViewById(R.id.webView);
        urlBar = findViewById(R.id.urlBar);
        progress = findViewById(R.id.progress);

        // 讓電腦 Chrome 的 chrome://inspect 也能連進來除錯（USB 偵錯）
        WebView.setWebContentsDebuggingEnabled(true);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        mobileUa = s.getUserAgentString();
        if (prefs.getBoolean("desktop", false)) s.setUserAgentString(DESKTOP_UA);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String scheme = r.getUrl().getScheme();
                if ("http".equals(scheme) || "https".equals(scheme)) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, r.getUrl())); } catch (Exception ignored) {}
                return true;
            }
            @Override public void onPageStarted(WebView v, String url, Bitmap f) {
                if (!urlBar.hasFocus()) urlBar.setText(url);
            }
            @Override public void onPageFinished(WebView v, String url) {
                if (!urlBar.hasFocus()) urlBar.setText(url);
                if (prefs.getBoolean("auto", false)) injectEruda(false);
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView v, int p) {
                progress.setProgress(p);
                progress.setVisibility(p >= 100 ? View.INVISIBLE : View.VISIBLE);
            }
        });
        web.setDownloadListener((url, ua, cd, mime, len) -> {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception ignored) {}
        });

        urlBar.setOnEditorActionListener((v, id, e) -> {
            if (id == EditorInfo.IME_ACTION_GO || (e != null && e.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                go(urlBar.getText().toString());
                return true;
            }
            return false;
        });
        findViewById(R.id.btnBack).setOnClickListener(v -> { if (web.canGoBack()) web.goBack(); });
        findViewById(R.id.btnF12).setOnClickListener(v -> injectEruda(true));
        findViewById(R.id.btnMenu).setOnClickListener(this::showMenu);

        Uri data = getIntent().getData();
        if (b != null) web.restoreState(b);
        else web.loadUrl(data != null ? data.toString() : HOME);
    }

    private void go(String in) {
        in = in.trim();
        if (in.isEmpty()) return;
        String url;
        if (in.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) url = in;
        else if (!in.contains(" ") && in.contains(".")) url = "https://" + in;
        else {
            try { url = "https://www.google.com/search?q=" + URLEncoder.encode(in, "UTF-8"); }
            catch (Exception e) { url = HOME; }
        }
        web.loadUrl(url);
        urlBar.clearFocus();
        ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
        web.requestFocus();
    }

    /** 注入 Eruda（手機版開發者工具）。toggle=true 時切換顯示/隱藏 */
    private void injectEruda(boolean toggle) {
        if (erudaJs == null) erudaJs = readAsset("eruda.js");
        String js = "(function(){"
            + "if(!window.eruda){" + erudaJs + "\n;eruda.init();" + (toggle ? "eruda.show();" : "") + "return;}"
            + (toggle ? "var d=eruda._devTools;if(d&&d._isShow)eruda.hide();else eruda.show();" : "")
            + "})();";
        web.evaluateJavascript(js, null);
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[16384]; int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } catch (IOException e) { return "alert('eruda 載入失敗');"; }
    }

    private void showMenu(View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor);
        pm.getMenuInflater().inflate(R.menu.main, pm.getMenu());
        pm.getMenu().findItem(R.id.m_auto).setChecked(prefs.getBoolean("auto", false));
        pm.getMenu().findItem(R.id.m_desktop).setChecked(prefs.getBoolean("desktop", false));
        pm.setOnMenuItemClickListener(item -> {
            int id = item.getItemId();
            if (id == R.id.m_reload) web.reload();
            else if (id == R.id.m_forward) { if (web.canGoForward()) web.goForward(); }
            else if (id == R.id.m_source) viewDomSource();
            else if (id == R.id.m_raw) viewRawSource();
            else if (id == R.id.m_auto) {
                boolean on = !prefs.getBoolean("auto", false);
                prefs.edit().putBoolean("auto", on).apply();
                if (on) injectEruda(false);
            } else if (id == R.id.m_desktop) {
                boolean on = !prefs.getBoolean("desktop", false);
                prefs.edit().putBoolean("desktop", on).apply();
                web.getSettings().setUserAgentString(on ? DESKTOP_UA : mobileUa);
                web.reload();
            } else if (id == R.id.m_clear) {
                web.clearCache(true);
                CookieManager.getInstance().removeAllCookies(null);
                WebStorage.getInstance().deleteAllData();
                Toast.makeText(this, "已清除", Toast.LENGTH_SHORT).show();
            }
            return true;
        });
        pm.show();
    }

    /** 目前畫面上的 DOM（含 JS 動態產生的內容） */
    private void viewDomSource() {
        web.evaluateJavascript("document.documentElement.outerHTML", v -> {
            String html;
            try { html = new org.json.JSONArray("[" + v + "]").getString(0); }
            catch (Exception e) { html = v; }
            openSource(web.getUrl(), "<!-- 目前 DOM -->\n" + html);
        });
    }

    /** 重新向伺服器抓取原始 HTML（等同電腦的 view-source:） */
    private void viewRawSource() {
        final String url = web.getUrl();
        final String ua = web.getSettings().getUserAgentString();
        final String cookie = CookieManager.getInstance().getCookie(url);
        Toast.makeText(this, "抓取中…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            String result;
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                c.setRequestProperty("User-Agent", ua);
                if (cookie != null) c.setRequestProperty("Cookie", cookie);
                c.setConnectTimeout(15000); c.setReadTimeout(20000);
                InputStream in = c.getResponseCode() >= 400 ? c.getErrorStream() : c.getInputStream();
                BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
                StringBuilder sb = new StringBuilder();
                sb.append("<!-- HTTP ").append(c.getResponseCode()).append(" ").append(c.getContentType()).append(" -->\n");
                String line;
                while ((line = r.readLine()) != null) sb.append(line).append('\n');
                result = sb.toString();
            } catch (Exception e) { result = "抓取失敗：" + e; }
            final String out = result;
            runOnUiThread(() -> openSource(url, out));
        }).start();
    }

    private void openSource(String url, String text) {
        SourceActivity.pending = text;
        startActivity(new Intent(this, SourceActivity.class).putExtra("url", url));
    }

    @Override public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
    @Override protected void onSaveInstanceState(Bundle o) { super.onSaveInstanceState(o); web.saveState(o); }
    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        if (i.getData() != null) web.loadUrl(i.getData().toString());
    }
}
