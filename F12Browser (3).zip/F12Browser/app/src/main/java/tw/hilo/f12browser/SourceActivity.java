package tw.hilo.f12browser;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Spannable;
import android.text.style.BackgroundColorSpan;
import android.view.ViewGroup;
import android.widget.*;

/** 顯示原始碼：可搜尋、複製、自動換行 */
public class SourceActivity extends Activity {
    static String pending = "";
    private TextView tv;
    private ScrollView scroll;
    private int lastIdx = -1;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        String text = pending == null ? "" : pending;
        setTitle(getIntent().getStringExtra("url"));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        LinearLayout bar = new LinearLayout(this);
        EditText find = new EditText(this);
        find.setHint("搜尋原始碼"); find.setSingleLine(true);
        Button next = new Button(this); next.setText("找");
        Button copy = new Button(this); copy.setText("複製");
        bar.addView(find, new LinearLayout.LayoutParams(0, -2, 1));
        bar.addView(next); bar.addView(copy);
        root.addView(bar);

        tv = new TextView(this);
        tv.setTypeface(Typeface.MONOSPACE);
        tv.setTextSize(11);
        tv.setTextIsSelectable(true);
        tv.setPadding(16, 8, 16, 8);
        tv.setText(text, TextView.BufferType.SPANNABLE);
        scroll = new ScrollView(this);
        scroll.addView(tv);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        copy.setOnClickListener(v -> {
            ((ClipboardManager) getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("source", text));
            Toast.makeText(this, "已複製", Toast.LENGTH_SHORT).show();
        });
        next.setOnClickListener(v -> {
            String q = find.getText().toString();
            if (q.isEmpty()) return;
            String low = text.toLowerCase();
            int i = low.indexOf(q.toLowerCase(), lastIdx + 1);
            if (i < 0) i = low.indexOf(q.toLowerCase());
            if (i < 0) { Toast.makeText(this, "找不到", Toast.LENGTH_SHORT).show(); return; }
            lastIdx = i;
            Spannable sp = (Spannable) tv.getText();
            for (BackgroundColorSpan s : sp.getSpans(0, sp.length(), BackgroundColorSpan.class)) sp.removeSpan(s);
            sp.setSpan(new BackgroundColorSpan(0xFFFFEB3B), i, i + q.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            final int pos = i;
            tv.post(() -> {
                int line = tv.getLayout().getLineForOffset(pos);
                scroll.smoothScrollTo(0, tv.getLayout().getLineTop(line));
            });
        });
    }
}
