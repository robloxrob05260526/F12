package tw.hilo.f12browser;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.*;
import android.widget.*;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final String HOME = "https://www.google.com";
    private static final String DESKTOP_UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36";

    private WebView web;
    private EditText urlBar;
    private ProgressBar progress;
    private SharedPreferences prefs;
    private String erudaJs;
    private String mobileUa;
    /** 每次啟動隨機產生，防止 iframe 內的別站網頁呼叫原生執行介面 */
    private final String token = Long.toHexString(new SecureRandom().nextLong());
    private volatile String cspInfo = "尚未攔截";
    private String swReloadedUrl = null;
    private static final Pattern HEAD_TAG = Pattern.compile("<head[^>]*>", Pattern.CASE_INSENSITIVE);
    /** 注入到每個主頁面最前面：停用 Service Worker（避免頁面從快取載入、繞過 CSP 移除） */
    private static final String EARLY_JS = "<script>try{if(navigator.serviceWorker){"
        + "navigator.serviceWorker.register=function(){return Promise.reject(new Error('Service Worker 已被 F12 瀏覽器停用'))};"
        + "navigator.serviceWorker.getRegistrations().then(function(r){r.forEach(function(x){x.unregister()})})}}catch(e){}</script>";
    private static final Pattern META_CSP = Pattern.compile(
        "<meta[^>]+http-equiv\\s*=\\s*[\"']?content-security-policy[^>]*>", Pattern.CASE_INSENSITIVE);

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("f12", MODE_PRIVATE);
        web = findViewById(R.id.webView);
        urlBar = findViewById(R.id.urlBar);
        progress = findViewById(R.id.progress);

        // 讓電腦 Chrome 的 chrome://inspect 也能連進來除錯（USB 偵錯）
        WebView.setWebContentsDebuggingEnabled(true);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        mobileUa = s.getUserAgentString();
        if (prefs.getBoolean("desktop", false)) s.setUserAgentString(DESKTOP_UA);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        web.addJavascriptInterface(new Bridge(), "F12Native");
        // Service Worker 發出的網頁請求也一併移除 CSP
        ServiceWorkerController.getInstance().setServiceWorkerClient(new ServiceWorkerClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebResourceRequest r) {
                if (!prefs.getBoolean("nocsp", true) || !"GET".equalsIgnoreCase(r.getMethod())) return null;
                String accept = r.getRequestHeaders().get("Accept");
                if (accept == null || !accept.contains("text/html")) return null;
                return fetchWithoutCsp(r);
            }
        });

        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                if (!prefs.getBoolean("nocsp", true)) return null;
                if (!r.isForMainFrame() || !"GET".equalsIgnoreCase(r.getMethod())) return null;
                return fetchWithoutCsp(r);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String scheme = r.getUrl().getScheme();
                if ("http".equals(scheme) || "https".equals(scheme)) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, r.getUrl())); } catch (Exception ignored) {}
                return true;
            }
            @Override public void onPageStarted(WebView v, String url, Bitmap f) {
                if (!urlBar.hasFocus()) urlBar.setText(url);
            }
            @Override public void onPageFinished(WebView v, String url) {
                if (!urlBar.hasFocus()) urlBar.setText(url);
                if (prefs.getBoolean("nocsp", true) && !url.equals(swReloadedUrl)) {
                    // 頁面若由 Service Worker 快取提供，CSP 沒被移除 → 解除註冊後重新載入一次
                    v.evaluateJavascript("(navigator.serviceWorker&&navigator.serviceWorker.controller)?"
                        + "(navigator.serviceWorker.getRegistrations().then(function(r){r.forEach(function(x){x.unregister()})}),'sw'):'no'",
                        r -> { if ("\"sw\"".equals(r)) { swReloadedUrl = url; cspInfo = "頁面原由 Service Worker 提供，已停用並重新載入";
                                 v.postDelayed(v::reload, 600); } });
                }
                if (prefs.getBoolean("auto", false)) injectEruda(false);
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView v, int p) {
                progress.setProgress(p);
                progress.setVisibility(p >= 100 ? View.INVISIBLE : View.VISIBLE);
            }
        });
        web.setDownloadListener((url, ua, cd, mime, len) -> {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception ignored) {}
        });

        urlBar.setOnEditorActionListener((v, id, e) -> {
            if (id == EditorInfo.IME_ACTION_GO || (e != null && e.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                go(urlBar.getText().toString());
                return true;
            }
            return false;
        });
        findViewById(R.id.btnBack).setOnClickListener(v -> { if (web.canGoBack()) web.goBack(); });
        findViewById(R.id.btnF12).setOnClickListener(v -> injectEruda(true));
        findViewById(R.id.btnMenu).setOnClickListener(this::showMenu);

        Uri data = getIntent().getData();
        if (b != null) web.restoreState(b);
        else web.loadUrl(data != null ? data.toString() : HOME);
    }

    private void go(String in) {
        in = in.trim();
        if (in.isEmpty()) return;
        String url;
        if (in.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) url = in;
        else if (!in.contains(" ") && in.contains(".")) url = "https://" + in;
        else {
            try { url = "https://www.google.com/search?q=" + URLEncoder.encode(in, "UTF-8"); }
            catch (Exception e) { url = HOME; }
        }
        web.loadUrl(url);
        urlBar.clearFocus();
        ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
        web.requestFocus();
    }

    /** 注入 Eruda（手機版開發者工具）。toggle=true 時切換顯示/隱藏 */
    private void injectEruda(boolean toggle) {
        if (erudaJs == null) erudaJs = readAsset("eruda.js");
        String js = "(function(){"
            + "if(!window.eruda){" + erudaJs + "\n;eruda.init();" + patchJs() + (toggle ? "eruda.show();" : "") + "return;}"
            + (toggle ? "var d=eruda._devTools;if(d&&d._isShow)eruda.hide();else eruda.show();" : "")
            + "})();";
        web.evaluateJavascript(js, null);
    }

    /**
     * 讓 Console 不受網頁 CSP（禁止 eval）限制：
     * 先照常 eval；若被擋（EvalError），改交給 App 原生 evaluateJavascript 執行，它不受 CSP 管。
     */
    private String patchJs() {
        return "(function(){var T='" + token + "';var L=eruda.get('console')._logger;var seq=0,q={};"
            + "var orig=L.evalJs.bind(L);"
            + "L.evaluate=function(c){var me=this;me.insert({type:'input',args:[c],ignoreFilter:true});"
            + "try{me.output(orig(c));}catch(e){"
            + "if(e instanceof EvalError||/unsafe-eval|Content.Security.Policy|Trusted/i.test(String(e))){"
            + "var id=++seq;q[id]=1;F12Native.run(T,id,c);}"
            + "else me.insert({type:'error',ignoreFilter:true,args:[e]});}};"
            + "window.__f12done=function(id,k,v){if(!q[id])return;delete q[id];window.$_=v;"
            + "if(k===1)L.insert({type:'error',ignoreFilter:true,args:[v]});else L.output(v);};"
            + "setTimeout(function(){try{(0,eval)('1');console.log('[F12] 此頁 CSP 已解除，eval 可用');}"
            + "catch(e){console.warn('[F12] 此頁 CSP 仍在，Console 改用原生執行（你的程式碼裡若有 eval/new Function 仍會被擋）。狀態：'+F12Native.info(T));}},300);"
            + "})();";
    }

    /** 從 JS 呼叫：以原生方式執行 Console 輸入的程式碼 */
    private class Bridge {
        @JavascriptInterface
        public String info(String t) { return token.equals(t) ? cspInfo : ""; }

        @JavascriptInterface
        public void run(String t, int id, String code) {
            if (!token.equals(t)) return;
            runOnUiThread(() -> {
                // 先當「運算式」執行，可回傳真正的物件給 Console 顯示
                String expr = "try{window.__f12done(" + id + ",0,(\n" + code + "\n))}"
                    + "catch(e){window.__f12done(" + id + ",1,e)}\n;'__f12ok'";
                web.evaluateJavascript(expr, r -> {
                    if ("\"__f12ok\"".equals(r)) return;
                    // 不是單一運算式（例如 let/for/function 宣告）→ 直接當一般程式執行
                    web.evaluateJavascript(code, r2 -> {
                        String out = (r2 == null || "null".equals(r2)) ? "undefined" : r2;
                        web.evaluateJavascript("window.__f12done&&window.__f12done(" + id + ",0,"
                            + ("undefined".equals(out) ? "undefined" : "JSON.parse(" + org.json.JSONObject.quote(out) + ")")
                            + ")", null);
                    });
                });
            });
        }
    }

    /** 自己抓主頁面，拿掉 Content-Security-Policy 標頭與 <meta> CSP，讓 eval 等功能可用 */
    private WebResourceResponse fetchWithoutCsp(WebResourceRequest r) {
        String url = r.getUrl().toString();
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(15000);
            c.setReadTimeout(30000);
            for (Map.Entry<String, String> h : r.getRequestHeaders().entrySet()) {
                String k = h.getKey();
                if (k.equalsIgnoreCase("Accept-Encoding") || k.equalsIgnoreCase("Cookie")) continue;
                c.setRequestProperty(k, h.getValue());
            }
            c.setRequestProperty("User-Agent", web.getSettings().getUserAgentString());
            CookieManager cm = CookieManager.getInstance();
            String cookie = cm.getCookie(url);
            if (cookie != null) c.setRequestProperty("Cookie", cookie);

            int code = c.getResponseCode();
            Map<String, List<String>> hdr = c.getHeaderFields();
            List<String> setCookies = null;
            for (Map.Entry<String, List<String>> e : hdr.entrySet())
                if (e.getKey() != null && e.getKey().equalsIgnoreCase("Set-Cookie")) setCookies = e.getValue();
            if (setCookies != null) for (String sc : setCookies) cm.setCookie(url, sc);

            if (code >= 300 && code < 400) {
                // WebView 不會對轉址後的網址再呼叫攔截，所以自己用 JS 轉過去，下一頁才會再經過這裡
                String loc = c.getHeaderField("Location");
                c.disconnect();
                if (loc == null) return null;
                String target = new URL(new URL(url), loc).toString();
                cspInfo = "轉址 → " + target;
                String page = "<!DOCTYPE html><meta charset=utf-8><script>location.replace("
                    + org.json.JSONObject.quote(target) + ")</script>";
                return new WebResourceResponse("text/html", "UTF-8", 200, "OK", new HashMap<>(),
                    new ByteArrayInputStream(page.getBytes(StandardCharsets.UTF_8)));
            }

            String ctype = c.getContentType();
            String mime = "text/html", charset = "UTF-8";
            if (ctype != null) {
                String[] parts = ctype.split(";");
                mime = parts[0].trim();
                for (String pt : parts) {
                    pt = pt.trim();
                    if (pt.toLowerCase().startsWith("charset=")) charset = pt.substring(8).replace("\"", "").trim();
                }
            }
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            if (in == null) in = new ByteArrayInputStream(new byte[0]);
            if (mime.contains("html")) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[16384]; int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                in.close();
                // ISO-8859-1 一對一保留位元組，不會弄壞中文編碼
                String html = bo.toString("ISO-8859-1");
                int before = html.length();
                html = META_CSP.matcher(html).replaceAll("");
                boolean metaRemoved = html.length() != before;
                java.util.regex.Matcher hm = HEAD_TAG.matcher(html);
                html = hm.find() ? html.substring(0, hm.end()) + EARLY_JS + html.substring(hm.end()) : EARLY_JS + html;
                cspInfo = "已處理 " + url + (metaRemoved ? "（含 <meta> CSP）" : "");
                in = new ByteArrayInputStream(html.getBytes(StandardCharsets.ISO_8859_1));
            }
            Map<String, String> outH = new HashMap<>();
            for (Map.Entry<String, List<String>> e : hdr.entrySet()) {
                String k = e.getKey();
                if (k == null) continue;
                String lk = k.toLowerCase();
                if (lk.startsWith("content-security-policy") || lk.equals("set-cookie")
                    || lk.equals("content-length") || lk.equals("content-encoding")
                    || lk.equals("transfer-encoding") || lk.equals("content-type")) continue;
                outH.put(k, String.join(", ", e.getValue()));
            }
            String reason = c.getResponseMessage();
            if (reason == null || reason.isEmpty()) reason = "OK";
            return new WebResourceResponse(mime, charset, code, reason, outH, in);
        } catch (Exception e) {
            cspInfo = "抓取失敗，改用原本方式載入（CSP 仍在）：" + e;
            return null; // 失敗就照原本方式載入
        }
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[16384]; int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } catch (IOException e) { return "alert('eruda 載入失敗');"; }
    }

    private void showMenu(View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor);
        pm.getMenuInflater().inflate(R.menu.main, pm.getMenu());
        pm.getMenu().findItem(R.id.m_auto).setChecked(prefs.getBoolean("auto", false));
        pm.getMenu().findItem(R.id.m_nocsp).setChecked(prefs.getBoolean("nocsp", true));
        pm.getMenu().findItem(R.id.m_desktop).setChecked(prefs.getBoolean("desktop", false));
        pm.setOnMenuItemClickListener(item -> {
            int id = item.getItemId();
            if (id == R.id.m_reload) web.reload();
            else if (id == R.id.m_forward) { if (web.canGoForward()) web.goForward(); }
            else if (id == R.id.m_source) viewDomSource();
            else if (id == R.id.m_raw) viewRawSource();
            else if (id == R.id.m_auto) {
                boolean on = !prefs.getBoolean("auto", false);
                prefs.edit().putBoolean("auto", on).apply();
                if (on) injectEruda(false);
            } else if (id == R.id.m_nocsp) {
                boolean on = !prefs.getBoolean("nocsp", true);
                prefs.edit().putBoolean("nocsp", on).apply();
                web.reload();
            } else if (id == R.id.m_desktop) {
                boolean on = !prefs.getBoolean("desktop", false);
                prefs.edit().putBoolean("desktop", on).apply();
                web.getSettings().setUserAgentString(on ? DESKTOP_UA : mobileUa);
                web.reload();
            } else if (id == R.id.m_clear) {
                web.clearCache(true);
                CookieManager.getInstance().removeAllCookies(null);
                WebStorage.getInstance().deleteAllData();
                Toast.makeText(this, "已清除", Toast.LENGTH_SHORT).show();
            }
            return true;
        });
        pm.show();
    }

    /** 目前畫面上的 DOM（含 JS 動態產生的內容） */
    private void viewDomSource() {
        web.evaluateJavascript("document.documentElement.outerHTML", v -> {
            String html;
            try { html = new org.json.JSONArray("[" + v + "]").getString(0); }
            catch (Exception e) { html = v; }
            openSource(web.getUrl(), "<!-- 目前 DOM -->\n" + html);
        });
    }

    /** 重新向伺服器抓取原始 HTML（等同電腦的 view-source:） */
    private void viewRawSource() {
        final String url = web.getUrl();
        final String ua = web.getSettings().getUserAgentString();
        final String cookie = CookieManager.getInstance().getCookie(url);
        Toast.makeText(this, "抓取中…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            String result;
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                c.setRequestProperty("User-Agent", ua);
                if (cookie != null) c.setRequestProperty("Cookie", cookie);
                c.setConnectTimeout(15000); c.setReadTimeout(20000);
                InputStream in = c.getResponseCode() >= 400 ? c.getErrorStream() : c.getInputStream();
                BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
                StringBuilder sb = new StringBuilder();
                sb.append("<!-- HTTP ").append(c.getResponseCode()).append(" ").append(c.getContentType()).append(" -->\n");
                String line;
                while ((line = r.readLine()) != null) sb.append(line).append('\n');
                result = sb.toString();
            } catch (Exception e) { result = "抓取失敗：" + e; }
            final String out = result;
            runOnUiThread(() -> openSource(url, out));
        }).start();
    }

    private void openSource(String url, String text) {
        SourceActivity.pending = text;
        startActivity(new Intent(this, SourceActivity.class).putExtra("url", url));
    }

    @Override public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
    @Override protected void onSaveInstanceState(Bundle o) { super.onSaveInstanceState(o); web.saveState(o); }
    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        if (i.getData() != null) web.loadUrl(i.getData().toString());
    }
}
